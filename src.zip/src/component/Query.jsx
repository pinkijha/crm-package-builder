import React from 'react'

const Query = () => {
  return (
    <div>
      query
    </div>
  )
}

export default Query
